Here are the steps to deploy an n8n automation pack on Render and Supabase, including OAuth, environment variables, and API connections:

**Supabase**

1. **Create a New Supabase Project**
   Go to supabase.io and create a new project. Choose the appropriate settings for your project.

2. **Set up OAuth**
   Navigate to the 'Authentication' section in your Supabase dashboard. 
   
   - Click on 'Settings'.
   - Go to 'External OAuth Providers'.
   - Fill in the required fields for your chosen OAuth provider. You can usually find these details in the settings of your OAuth provider's developer console. 
   - Click 'Save'.

3. **Add Environment Variables**
   In the Supabase dashboard, navigate to 'Settings' and select 'API'.
   
   - From here, you can add new environment variables.
   - Click on 'Add'.
   - Enter the variable name and its value.
   - Click 'Save'.

4. **API Connection**
   You can interact with your Supabase through the provided API. 
   
   - Go to 'API' in the Settings.
   - Copy the URL and API keys from the 'Config' section.
   - Use this information for making requests to your Supabase.

**Render**

1. **Create a new Render Application**
   Go to render.com and sign in. Create a new application and select the appropriate settings for your project.

2. **Set up OAuth**
   Navigate to the 'Environment' section in your Render dashboard.
   
   - Click on 'Add Environment Group'.
   - Add a new environment variable with the name of your OAuth provider (e.g., `RENDER_OAUTH_PROVIDER`), and set its value to the OAuth provider's name.
   - Add another environment variable with the name of your OAuth client ID (e.g., `RENDER_OAUTH_CLIENT_ID`), and set its value to your OAuth client ID.
   - Repeat the process for your OAuth client secret and callback URL.

3. **Add Environment Variables**
   In the Render dashboard, navigate to 'Environment'.
   
   - Click on 'Add Environment Group'.
   - Add a new environment variable with the name of your variable, and set its value.
   - Click 'Save'.

4. **API Connection**
   Render does not provide a direct API like Supabase, but you can integrate it with other services and APIs by adding the relevant environment variables and secrets.

**N8N**

After setting up Render and Supabase, you can integrate them with your n8n automation pack.

1. **Install n8n**
   Install n8n using npm with the command `npm install n8n -g`.

2. **Create a new Workflow**
   Run the command `n8n start --tunnel` to start n8n and create a new workflow.

3. **Set up OAuth**
   In the n8n workflow editor, add a new node and select your OAuth provider.
   
   - Enter the relevant credentials from Supabase or Render.
   - Save the node and connect it to the rest of your workflow.

4. **Add Environment Variables**
   You can add environment variables directly in the workflow editor or through the command line when starting n8n.

5. **API Connection**
   Add a new node in the workflow editor and select 'HTTP Request'.
   
   - Enter the URL and API keys from Supabase or Render.
   - Set the method to GET or POST depending on your needs.
   - Connect the node to the rest of your workflow.

After setting up everything, you should have a working n8n automation pack deployed on Render and Supabase.