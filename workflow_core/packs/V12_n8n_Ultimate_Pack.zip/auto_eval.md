As an AI model, I don't have the real-time ability to pull up specific updates on n8n versions. However, based on general software update practices, here are some potential improvements and changes that might have been made from n8n automation pack V11 to V12:

1. Feature Enhancements: New features could be introduced in V12 which were not available in V11. These new features usually aim at improving the user experience, functionality, and efficiency of the software.

2. Bug Fixes: Any issues or bugs that were identified in V11 could have been resolved in V12.

3. Performance Enhancements: The newer version might have improvements related to the performance of the software. This could include speed improvements, reduced memory usage, and more.

4. Security Updates: V12 might come with improved security measures to protect user data and prevent unauthorized access.

5. User Interface Changes: There could be changes in the user interface to make it more user-friendly and intuitive.

6. Workflow Changes: V12 might introduce changes in the workflow to simplify or enhance the automation process. This could include changes in how tasks are executed, new ways of managing workflows, or an improved method of workflow visualization.

7. Integration Updates: The newer version could have added or improved integration with other tools and services.

8. Documentation: Updates often come with improved documentation to help users understand and utilize the new features and updates.

To get specific details about the changes from n8n automation pack V11 to V12, you should refer to the official release notes provided by n8n.