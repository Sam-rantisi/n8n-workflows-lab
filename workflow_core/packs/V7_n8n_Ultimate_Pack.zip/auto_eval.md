As an AI, I don't have real-time data or access to specific product updates. As of my training data up to September 2021, there's no specific information available on n8n automation pack V6 and V7. The improvements or changes made from version V6 to V7 would depend on the specific issues or features the developers were focusing on at the time. 

Typically, newer software versions introduce improved functionality, bug fixes, and may include architectural changes for better performance, security, and usability. Sometimes, they may also introduce new features based on user feedback or technological advancements.

For the most accurate information, I would recommend checking the official n8n website or reaching out to their support for the version history and changes.