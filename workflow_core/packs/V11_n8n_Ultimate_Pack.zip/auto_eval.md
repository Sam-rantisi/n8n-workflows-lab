As an AI, I don't have the ability to access real-time updates or version-specific changes regarding specific software like n8n. However, I can tell you that typically, when software versions are updated, they often include the following improvements:

1. Bug Fixes: Any issues or bugs identified in the previous version are likely to be addressed and fixed.

2. New Features: New versions often introduce additional features that enhance the functionality and usability of the software.

3. Performance Enhancements: Improvements in speed, efficiency, and resource usage are common in newer versions.

4. User Interface (UI) Improvements: The UI may be updated to be more user-friendly, intuitive, or aesthetically pleasing.

5. Security Updates: New versions often include patches for any security vulnerabilities identified in previous versions.

For the specifics of what was introduced or changed in n8n's automation pack from V10 to V11, you would need to refer to their official release notes or updates.